/*
***************************************************************************
*
* Author: Zach Swena
*
* Copyright (C) 2010, 2011, 2014 Zach Swena All Rights Reserved
*
* zcybercomputing@gmail.com
*
***************************************************************************
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation version 2 of the License.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License along
* with this program; if not, write to the Free Software Foundation, Inc.,
* 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*
***************************************************************************
*
* This version of GPL is at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
*
***************************************************************************
*/
#include "stream.h"
#include "windows.h"
/// ========================================================================================================
stream::stream( QObject *parent) :
    QObject(parent)
{
    qDebug() << QThread::currentThreadId();
    qRegisterMetaType<QHostAddress>("QHostAddress");
    qRegisterMetaType<BufferList>("BufferList");
    qDebug("stream class initializer");
    worker = new Worker;
    connect(&workerThread, &QThread::finished, worker, &QObject::deleteLater);
    connect(worker,SIGNAL(done_streaming()),this,SLOT(done_with_worker()));
    connect(this, SIGNAL(start_stream( QHostAddress, qint16, QString )) , worker, SLOT(send_datagrams( QHostAddress, qint16, QString )) );
    worker->moveToThread(&workerThread);
    workerThread.start(QThread::TimeCriticalPriority);

    ip_stream_address.setAddress("239.0.0.230");
    ip_stream_port = 1234;
}

stream::~stream()
{
    qDebug("Stream Destructor");
    worker->loop=false;
    workerThread.quit();
    workerThread.wait();
    qDebug("Stream destructor finished");
}

void stream::start_streaming()
{
    start_stream( ip_stream_address, ip_stream_port , "C:/Users/Zach/Development/Test Files/122511-FixedVLC.ts" );
}

void stream::done_with_worker()
{
    emit done_with_stream();
    qDebug("done with stream signal sent");
}

Worker::Worker()
{
    qDebug("Worker init");

    loop=true;
    // Prepare constants to build datagram.
       pkts_PerDgram = 8;
       packet_size   = 188;
       dgram_size    = 188*pkts_PerDgram;

       //packet.fill('1',packet_size);
       //datagram.clear();
       //packet_index=0;

}

Worker::~Worker()
{
    qDebug("worker destructor");
}

QByteArray Worker::read_packet()
{
    QByteArray datagram;
    char ts_packet[188];
    int packets_read;
    datagram.clear();

    for(int index=1; index<= pkts_PerDgram ; index++)
    {
        packets_read = file.read(ts_packet,188);
        //qDebug() << "packet" << packets_read << "datagram" << datagram.size();
        datagram.append(QByteArray( (char*) ts_packet ,188));
    }

    return datagram;
}

void Worker::send_datagrams(QHostAddress stream_addr, qint16 stream_port, QString filename)
{
    qDebug() << QThread::currentThreadId();
    qDebug("Worker starting stream");
    file.setFileName(filename);
    QByteArray datagram;
    KbitRate = 3000;
    timer_freq = 8*188*8; // 8 bits per byte, ms between packets.
    timer_freq = timer_freq*1000000;
    timer_freq = timer_freq/(KbitRate);

    if (file.open(QIODevice::ReadOnly))
    {
        udp_streaming_socket = new QUdpSocket(this);
        elapsed_timer.start();
        while(loop)
        {
            datagram = read_packet();
            if( !datagram.isEmpty() )
            {

                while(elapsed_timer.nsecsElapsed() <= timer_freq)
                {
                    // spin until time to send next packet
                }
                save_file(datagram);
                socket_state = udp_streaming_socket->writeDatagram( datagram.data(), datagram.size() ,stream_addr , stream_port);
                udp_streaming_socket->waitForBytesWritten();
                elapsed_timer.restart();     // start elapsed timer
                if(socket_state<=0)
                {
                    qDebug()<< "Socket error "<< udp_streaming_socket->error();
                }
            }
            else
            {
                qDebug("datagram is empty");
                loop=false;
            }
        }
    /*
   // datagram_index = 0;

        qDebug() << "datagram index " << datagram_index << "datagram buffer size" << datagram_buffer.size();

        if(datagram_buffer.size()<=datagram_index)
        {
            emit done_streaming();
            //save_file(datagram_buffer);
            qDebug("done with stream");
            loop=false;
            break;
        }
        if(datagram_buffer.size()>datagram_index)
        {

            datagram_index++;
        }

    */
    udp_streaming_socket->close();
    }
    qDebug("Worker finished stream");
}
void Worker::save_file( QByteArray datagram)
{
    QFile file("qudp_test.ts");
    if(file.open(QIODevice::WriteOnly|QIODevice::Append))
    {
        QDataStream out(&file);
        out.writeRawData(datagram.data(),datagram.size());
        file.close();
    }
}
