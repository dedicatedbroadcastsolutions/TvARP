/****************************************************************************
** Meta object code from reading C++ file 'automation.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Source/automation.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'automation.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Automation_t {
    QByteArrayData data[32];
    char stringdata[369];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Automation_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Automation_t qt_meta_stringdata_Automation = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 16),
QT_MOC_LITERAL(2, 28, 0),
QT_MOC_LITERAL(3, 29, 4),
QT_MOC_LITERAL(4, 34, 8),
QT_MOC_LITERAL(5, 43, 15),
QT_MOC_LITERAL(6, 59, 11),
QT_MOC_LITERAL(7, 71, 8),
QT_MOC_LITERAL(8, 80, 17),
QT_MOC_LITERAL(9, 98, 4),
QT_MOC_LITERAL(10, 103, 16),
QT_MOC_LITERAL(11, 120, 19),
QT_MOC_LITERAL(12, 140, 16),
QT_MOC_LITERAL(13, 157, 17),
QT_MOC_LITERAL(14, 175, 11),
QT_MOC_LITERAL(15, 187, 14),
QT_MOC_LITERAL(16, 202, 18),
QT_MOC_LITERAL(17, 221, 16),
QT_MOC_LITERAL(18, 238, 8),
QT_MOC_LITERAL(19, 247, 11),
QT_MOC_LITERAL(20, 259, 9),
QT_MOC_LITERAL(21, 269, 10),
QT_MOC_LITERAL(22, 280, 11),
QT_MOC_LITERAL(23, 292, 9),
QT_MOC_LITERAL(24, 302, 3),
QT_MOC_LITERAL(25, 306, 11),
QT_MOC_LITERAL(26, 318, 7),
QT_MOC_LITERAL(27, 326, 8),
QT_MOC_LITERAL(28, 335, 7),
QT_MOC_LITERAL(29, 343, 12),
QT_MOC_LITERAL(30, 356, 7),
QT_MOC_LITERAL(31, 364, 4)
    },
    "Automation\0event_log_output\0\0play\0"
    "openFile\0get_video_state\0mux_eas_log\0"
    "eas_ring\0process_mux_debug\0data\0"
    "init_mux_control\0restart_mux_control\0"
    "init_ring_detect\0close_ring_detect\0"
    "handleError\0check_eas_ring\0"
    "stream_eas_message\0send_eas_message\0"
    "init_vlc\0restart_vlc\0start_vlc\0"
    "check_time\0video_state\0print_log\0log\0"
    "log_channel\0channel\0DateTime\0is_open\0"
    "log_playback\0message\0file"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Automation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      24,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  134,    2, 0x06 /* Public */,
       3,    0,  137,    2, 0x06 /* Public */,
       4,    1,  138,    2, 0x06 /* Public */,
       5,    0,  141,    2, 0x06 /* Public */,
       6,    1,  142,    2, 0x06 /* Public */,
       7,    0,  145,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,  146,    2, 0x0a /* Public */,
      10,    0,  149,    2, 0x0a /* Public */,
      11,    0,  150,    2, 0x0a /* Public */,
      12,    0,  151,    2, 0x0a /* Public */,
      13,    0,  152,    2, 0x0a /* Public */,
      14,    0,  153,    2, 0x0a /* Public */,
      15,    0,  154,    2, 0x0a /* Public */,
      16,    0,  155,    2, 0x0a /* Public */,
      17,    0,  156,    2, 0x0a /* Public */,
      18,    0,  157,    2, 0x0a /* Public */,
      19,    0,  158,    2, 0x0a /* Public */,
      20,    0,  159,    2, 0x0a /* Public */,
      21,    0,  160,    2, 0x0a /* Public */,
      22,    1,  161,    2, 0x0a /* Public */,
      23,    1,  164,    2, 0x0a /* Public */,
      25,    2,  167,    2, 0x0a /* Public */,
      28,    1,  172,    2, 0x0a /* Public */,
      29,    3,  175,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,   24,
    QMetaType::Void, QMetaType::Int, QMetaType::QDateTime,   26,   27,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QDateTime,   30,   31,   27,

       0        // eod
};

void Automation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Automation *_t = static_cast<Automation *>(_o);
        switch (_id) {
        case 0: _t->event_log_output((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->play(); break;
        case 2: _t->openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->get_video_state(); break;
        case 4: _t->mux_eas_log((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->eas_ring(); break;
        case 6: _t->process_mux_debug((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->init_mux_control(); break;
        case 8: _t->restart_mux_control(); break;
        case 9: _t->init_ring_detect(); break;
        case 10: _t->close_ring_detect(); break;
        case 11: _t->handleError(); break;
        case 12: _t->check_eas_ring(); break;
        case 13: _t->stream_eas_message(); break;
        case 14: _t->send_eas_message(); break;
        case 15: _t->init_vlc(); break;
        case 16: _t->restart_vlc(); break;
        case 17: _t->start_vlc(); break;
        case 18: _t->check_time(); break;
        case 19: _t->video_state((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->print_log((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->log_channel((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 22: _t->is_open((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->log_playback((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QDateTime(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Automation::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::event_log_output)) {
                *result = 0;
            }
        }
        {
            typedef void (Automation::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::play)) {
                *result = 1;
            }
        }
        {
            typedef void (Automation::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::openFile)) {
                *result = 2;
            }
        }
        {
            typedef void (Automation::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::get_video_state)) {
                *result = 3;
            }
        }
        {
            typedef void (Automation::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::mux_eas_log)) {
                *result = 4;
            }
        }
        {
            typedef void (Automation::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::eas_ring)) {
                *result = 5;
            }
        }
    }
}

const QMetaObject Automation::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Automation.data,
      qt_meta_data_Automation,  qt_static_metacall, 0, 0}
};


const QMetaObject *Automation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Automation::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Automation.stringdata))
        return static_cast<void*>(const_cast< Automation*>(this));
    return QObject::qt_metacast(_clname);
}

int Automation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 24)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 24;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 24)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 24;
    }
    return _id;
}

// SIGNAL 0
void Automation::event_log_output(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Automation::play()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Automation::openFile(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Automation::get_video_state()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void Automation::mux_eas_log(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Automation::eas_ring()
{
    QMetaObject::activate(this, &staticMetaObject, 5, 0);
}
QT_END_MOC_NAMESPACE
