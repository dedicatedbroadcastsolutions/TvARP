/****************************************************************************
** Meta object code from reading C++ file 'eas.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Source/eas.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'eas.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_EAS_t {
    QByteArrayData data[15];
    char stringdata[200];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_EAS_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_EAS_t qt_meta_stringdata_EAS = {
    {
QT_MOC_LITERAL(0, 0, 3),
QT_MOC_LITERAL(1, 4, 8),
QT_MOC_LITERAL(2, 13, 0),
QT_MOC_LITERAL(3, 14, 15),
QT_MOC_LITERAL(4, 30, 10),
QT_MOC_LITERAL(5, 41, 10),
QT_MOC_LITERAL(6, 52, 14),
QT_MOC_LITERAL(7, 67, 16),
QT_MOC_LITERAL(8, 84, 14),
QT_MOC_LITERAL(9, 99, 11),
QT_MOC_LITERAL(10, 111, 20),
QT_MOC_LITERAL(11, 132, 19),
QT_MOC_LITERAL(12, 152, 18),
QT_MOC_LITERAL(13, 171, 18),
QT_MOC_LITERAL(14, 190, 9)
    },
    "EAS\0eas_ring\0\0send_eas_config\0QList<int>\0"
    "start_send\0eas_log_output\0send_eas_message\0"
    "check_eas_ring\0handleError\0"
    "process_serial_debug\0init_vlc_start_play\0"
    "setArgs_InitLibVlc\0stream_eas_message\0"
    "fake_ring"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_EAS[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x06 /* Public */,
       3,    1,   75,    2, 0x06 /* Public */,
       5,    0,   78,    2, 0x06 /* Public */,
       6,    1,   79,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,   82,    2, 0x0a /* Public */,
       8,    0,   83,    2, 0x0a /* Public */,
       9,    0,   84,    2, 0x0a /* Public */,
      10,    0,   85,    2, 0x0a /* Public */,
      11,    0,   86,    2, 0x0a /* Public */,
      12,    0,   87,    2, 0x0a /* Public */,
      13,    0,   88,    2, 0x0a /* Public */,
      14,    0,   89,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void EAS::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        EAS *_t = static_cast<EAS *>(_o);
        switch (_id) {
        case 0: _t->eas_ring(); break;
        case 1: _t->send_eas_config((*reinterpret_cast< QList<int>(*)>(_a[1]))); break;
        case 2: _t->start_send(); break;
        case 3: _t->eas_log_output((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->send_eas_message(); break;
        case 5: _t->check_eas_ring(); break;
        case 6: _t->handleError(); break;
        case 7: _t->process_serial_debug(); break;
        case 8: _t->init_vlc_start_play(); break;
        case 9: _t->setArgs_InitLibVlc(); break;
        case 10: _t->stream_eas_message(); break;
        case 11: _t->fake_ring(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<int> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (EAS::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&EAS::eas_ring)) {
                *result = 0;
            }
        }
        {
            typedef void (EAS::*_t)(QList<int> );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&EAS::send_eas_config)) {
                *result = 1;
            }
        }
        {
            typedef void (EAS::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&EAS::start_send)) {
                *result = 2;
            }
        }
        {
            typedef void (EAS::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&EAS::eas_log_output)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject EAS::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_EAS.data,
      qt_meta_data_EAS,  qt_static_metacall, 0, 0}
};


const QMetaObject *EAS::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *EAS::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_EAS.stringdata))
        return static_cast<void*>(const_cast< EAS*>(this));
    return QObject::qt_metacast(_clname);
}

int EAS::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void EAS::eas_ring()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void EAS::send_eas_config(QList<int> _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void EAS::start_send()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void EAS::eas_log_output(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
