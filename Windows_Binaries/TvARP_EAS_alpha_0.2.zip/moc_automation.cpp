/****************************************************************************
** Meta object code from reading C++ file 'automation.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Source/automation.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'automation.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Automation_t {
    QByteArrayData data[18];
    char stringdata[169];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Automation_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Automation_t qt_meta_stringdata_Automation = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 16),
QT_MOC_LITERAL(2, 28, 0),
QT_MOC_LITERAL(3, 29, 9),
QT_MOC_LITERAL(4, 39, 4),
QT_MOC_LITERAL(5, 44, 8),
QT_MOC_LITERAL(6, 53, 15),
QT_MOC_LITERAL(7, 69, 10),
QT_MOC_LITERAL(8, 80, 11),
QT_MOC_LITERAL(9, 92, 9),
QT_MOC_LITERAL(10, 102, 3),
QT_MOC_LITERAL(11, 106, 11),
QT_MOC_LITERAL(12, 118, 7),
QT_MOC_LITERAL(13, 126, 8),
QT_MOC_LITERAL(14, 135, 7),
QT_MOC_LITERAL(15, 143, 12),
QT_MOC_LITERAL(16, 156, 7),
QT_MOC_LITERAL(17, 164, 4)
    },
    "Automation\0event_log_output\0\0new_event\0"
    "play\0openFile\0get_video_state\0check_time\0"
    "video_state\0print_log\0log\0log_channel\0"
    "channel\0DateTime\0is_open\0log_playback\0"
    "message\0file"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Automation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   64,    2, 0x06 /* Public */,
       4,    0,   67,    2, 0x06 /* Public */,
       5,    1,   68,    2, 0x06 /* Public */,
       6,    0,   71,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    0,   72,    2, 0x0a /* Public */,
       8,    1,   73,    2, 0x0a /* Public */,
       9,    1,   76,    2, 0x0a /* Public */,
      11,    2,   79,    2, 0x0a /* Public */,
      14,    1,   84,    2, 0x0a /* Public */,
      15,    3,   87,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::Int, QMetaType::QDateTime,   12,   13,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QDateTime,   16,   17,   13,

       0        // eod
};

void Automation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Automation *_t = static_cast<Automation *>(_o);
        switch (_id) {
        case 0: _t->event_log_output((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->play(); break;
        case 2: _t->openFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: _t->get_video_state(); break;
        case 4: _t->check_time(); break;
        case 5: _t->video_state((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->print_log((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->log_channel((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2]))); break;
        case 8: _t->is_open((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->log_playback((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QDateTime(*)>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (Automation::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::event_log_output)) {
                *result = 0;
            }
        }
        {
            typedef void (Automation::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::play)) {
                *result = 1;
            }
        }
        {
            typedef void (Automation::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::openFile)) {
                *result = 2;
            }
        }
        {
            typedef void (Automation::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&Automation::get_video_state)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject Automation::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_Automation.data,
      qt_meta_data_Automation,  qt_static_metacall, 0, 0}
};


const QMetaObject *Automation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Automation::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Automation.stringdata))
        return static_cast<void*>(const_cast< Automation*>(this));
    return QObject::qt_metacast(_clname);
}

int Automation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void Automation::event_log_output(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Automation::play()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void Automation::openFile(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void Automation::get_video_state()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}
QT_END_MOC_NAMESPACE
