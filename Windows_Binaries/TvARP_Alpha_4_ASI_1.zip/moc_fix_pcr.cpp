/****************************************************************************
** Meta object code from reading C++ file 'fix_pcr.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../Source/fix_pcr.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'fix_pcr.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_fix_pcr_t {
    QByteArrayData data[35];
    char stringdata[432];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_fix_pcr_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_fix_pcr_t qt_meta_stringdata_fix_pcr = {
    {
QT_MOC_LITERAL(0, 0, 7),
QT_MOC_LITERAL(1, 8, 7),
QT_MOC_LITERAL(2, 16, 0),
QT_MOC_LITERAL(3, 17, 11),
QT_MOC_LITERAL(4, 29, 5),
QT_MOC_LITERAL(5, 35, 13),
QT_MOC_LITERAL(6, 49, 17),
QT_MOC_LITERAL(7, 67, 5),
QT_MOC_LITERAL(8, 73, 8),
QT_MOC_LITERAL(9, 82, 13),
QT_MOC_LITERAL(10, 96, 13),
QT_MOC_LITERAL(11, 110, 9),
QT_MOC_LITERAL(12, 120, 32),
QT_MOC_LITERAL(13, 153, 4),
QT_MOC_LITERAL(14, 158, 11),
QT_MOC_LITERAL(15, 170, 8),
QT_MOC_LITERAL(16, 179, 18),
QT_MOC_LITERAL(17, 198, 14),
QT_MOC_LITERAL(18, 213, 17),
QT_MOC_LITERAL(19, 231, 8),
QT_MOC_LITERAL(20, 240, 8),
QT_MOC_LITERAL(21, 249, 6),
QT_MOC_LITERAL(22, 256, 15),
QT_MOC_LITERAL(23, 272, 3),
QT_MOC_LITERAL(24, 276, 9),
QT_MOC_LITERAL(25, 286, 11),
QT_MOC_LITERAL(26, 298, 12),
QT_MOC_LITERAL(27, 311, 16),
QT_MOC_LITERAL(28, 328, 6),
QT_MOC_LITERAL(29, 335, 12),
QT_MOC_LITERAL(30, 348, 6),
QT_MOC_LITERAL(31, 355, 2),
QT_MOC_LITERAL(32, 358, 6),
QT_MOC_LITERAL(33, 365, 15),
QT_MOC_LITERAL(34, 381, 50)
    },
    "fix_pcr\0kill_me\0\0vlcFix_Send\0char*\0"
    "vlcOutputFile\0readPktIntoBuffer\0FILE*\0"
    "origFile\0processVidPkt\0processAudPkt\0"
    "outputPkt\0outputNulls_Pkts_ByRatio_CalcPcr\0"
    "int&\0nullsNeeded\0nonNulls\0nulls_nonNullsLoop\0"
    "nullLoop_Ratio\0nonNullLoop_Ratio\0"
    "stampPcr\0pcrValue\0jitter\0unsigned char[]\0"
    "pkt\0removePcr\0writeOutput\0buildNullPkt\0"
    "buildVidPktZeros\0getPcr\0showPtsDelay\0"
    "offset\0av\0getPts\0findFirstPcrLoc\0"
    "getNulls_Pkts_Ratios_CalcPcr_LookaheadToNextOldPcr"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_fix_pcr[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    1,  100,    2, 0x0a /* Public */,
       6,    1,  103,    2, 0x08 /* Private */,
       9,    0,  106,    2, 0x08 /* Private */,
      10,    0,  107,    2, 0x08 /* Private */,
      11,    1,  108,    2, 0x08 /* Private */,
      12,    6,  111,    2, 0x08 /* Private */,
      19,    3,  124,    2, 0x08 /* Private */,
      24,    1,  131,    2, 0x08 /* Private */,
      25,    1,  134,    2, 0x08 /* Private */,
      26,    0,  137,    2, 0x08 /* Private */,
      27,    0,  138,    2, 0x08 /* Private */,
      28,    0,  139,    2, 0x08 /* Private */,
      29,    2,  140,    2, 0x08 /* Private */,
      32,    1,  145,    2, 0x08 /* Private */,
      33,    1,  148,    2, 0x08 /* Private */,
      34,    6,  151,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Int, 0x80000000 | 7,    8,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13,    8,   14,   15,   16,   17,   18,
    QMetaType::Void, QMetaType::LongLong, QMetaType::Int, 0x80000000 | 22,   20,   21,   23,
    QMetaType::Void, 0x80000000 | 22,   23,
    QMetaType::Void, 0x80000000 | 22,   23,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::LongLong,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 4,   30,   31,
    QMetaType::LongLong, QMetaType::Int,   30,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13, 0x80000000 | 13,    8,   14,   15,   16,   17,   18,

       0        // eod
};

void fix_pcr::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        fix_pcr *_t = static_cast<fix_pcr *>(_o);
        switch (_id) {
        case 0: _t->kill_me(); break;
        case 1: _t->vlcFix_Send((*reinterpret_cast< char*(*)>(_a[1]))); break;
        case 2: { int _r = _t->readPktIntoBuffer((*reinterpret_cast< FILE*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 3: { bool _r = _t->processVidPkt();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: { bool _r = _t->processAudPkt();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 5: _t->outputPkt((*reinterpret_cast< FILE*(*)>(_a[1]))); break;
        case 6: _t->outputNulls_Pkts_ByRatio_CalcPcr((*reinterpret_cast< FILE*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        case 7: _t->stampPcr((*reinterpret_cast< long long(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< unsigned char(*)[]>(_a[3]))); break;
        case 8: _t->removePcr((*reinterpret_cast< unsigned char(*)[]>(_a[1]))); break;
        case 9: _t->writeOutput((*reinterpret_cast< unsigned char(*)[]>(_a[1]))); break;
        case 10: _t->buildNullPkt(); break;
        case 11: _t->buildVidPktZeros(); break;
        case 12: { long long _r = _t->getPcr();
            if (_a[0]) *reinterpret_cast< long long*>(_a[0]) = _r; }  break;
        case 13: _t->showPtsDelay((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< char*(*)>(_a[2]))); break;
        case 14: { long long _r = _t->getPts((*reinterpret_cast< int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< long long*>(_a[0]) = _r; }  break;
        case 15: _t->findFirstPcrLoc((*reinterpret_cast< FILE*(*)>(_a[1]))); break;
        case 16: _t->getNulls_Pkts_Ratios_CalcPcr_LookaheadToNextOldPcr((*reinterpret_cast< FILE*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< int(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (fix_pcr::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&fix_pcr::kill_me)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject fix_pcr::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_fix_pcr.data,
      qt_meta_data_fix_pcr,  qt_static_metacall, 0, 0}
};


const QMetaObject *fix_pcr::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *fix_pcr::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_fix_pcr.stringdata))
        return static_cast<void*>(const_cast< fix_pcr*>(this));
    return QObject::qt_metacast(_clname);
}

int fix_pcr::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void fix_pcr::kill_me()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
